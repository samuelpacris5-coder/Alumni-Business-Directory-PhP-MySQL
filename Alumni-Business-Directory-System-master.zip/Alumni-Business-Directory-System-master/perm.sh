chmod -R 755 .
